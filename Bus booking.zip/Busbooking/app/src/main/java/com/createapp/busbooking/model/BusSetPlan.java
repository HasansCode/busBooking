package com.createapp.busbooking.model;

public class BusSetPlan {
    public String setName;

    public BusSetPlan(String setName) {
        this.setName = setName;
    }

    public String getSetName() {
        return setName;
    }

    public void setSetName(String setName) {
        this.setName = setName;
    }
}
