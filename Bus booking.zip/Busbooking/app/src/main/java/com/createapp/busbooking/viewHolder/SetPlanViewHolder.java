package com.createapp.busbooking.viewHolder;

import android.view.View;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.createapp.busbooking.R;

public class SetPlanViewHolder extends RecyclerView.ViewHolder {
    public ToggleButton toggleButton;
    public SetPlanViewHolder(@NonNull View itemView) {
        super(itemView);
        toggleButton = itemView.findViewById(R.id.toggleButton);

    }
}
