package com.createapp.busbooking.adapter;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.createapp.busbooking.R;
import com.createapp.busbooking.model.BusInfo;
import com.createapp.busbooking.model.BusSetPlan;
import com.createapp.busbooking.viewHolder.SetPlanViewHolder;

import java.util.List;

public class SetPlanAdapter extends RecyclerView.Adapter<SetPlanViewHolder> {

    Context context;
    List<BusSetPlan> busSetPlanList;
    Button confirmBtn;

    public SetPlanAdapter(Context context, List<BusSetPlan> busSetPlanList, Button confirmBtn) {
        this.context = context;
        this.busSetPlanList = busSetPlanList;
        this.confirmBtn = confirmBtn;
    }

    @NonNull
    @Override
    public SetPlanViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.set_plan,parent,false);
        return new SetPlanViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SetPlanViewHolder holder, int position) {
        BusSetPlan busSetPlan = busSetPlanList.get(position);


        holder.toggleButton.setTextOn(busSetPlan.getSetName());



        holder.toggleButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // The toggle is enabled
                holder.toggleButton.setBackgroundColor(Color.argb(255, 155, 255, 95));
                confirmBtn.setVisibility(View.VISIBLE);


            } else {
                // The toggle is disabled
                holder.toggleButton.setBackgroundColor(Color.argb(255, 0, 0, 0));

            }
        });


    }

    @Override
    public int getItemCount() {


        return busSetPlanList.size();
    }
}
